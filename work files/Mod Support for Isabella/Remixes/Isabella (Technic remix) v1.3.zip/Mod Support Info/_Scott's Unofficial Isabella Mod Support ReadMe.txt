Scott's Unofficial Isabella Mod Support
http://www.minecraftforum.net/topic/882510-

CREDITS:
When playing MineCraft, I use bonemouse's Isabella textures exclusively.

Isabella can be found at http://www.minecraftforum.net/topic/242175-

INSTALLATION:
Using an archive program such as 7zip or winrar, place the contents of this pack into the root directory of the Isabella texture pack archive.
